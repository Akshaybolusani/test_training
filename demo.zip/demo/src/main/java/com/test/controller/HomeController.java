package com.test.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController // Marks this as a REST controller
@RequestMapping("/api") // Base URL for this controller
public class HomeController {

    @GetMapping("/hello") // Maps this method to /api/hello
    public String hello() {
        return "Hello, Spring Boot is working!";
    }
}
