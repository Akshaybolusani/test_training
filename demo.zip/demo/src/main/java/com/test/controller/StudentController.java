package com.test.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.test.service.StudentService; // Corrected package and service name
import com.test.entity.Student;

@RestController
@CrossOrigin("*")
public class StudentController {
    
    @Autowired
    private StudentService service; // Updated service name
    
    @GetMapping("/student_table")
    public List<Student> getAllStudents() { // Updated method name
        return service.getAllStudents();
    }
}
