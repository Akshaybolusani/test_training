package com.test.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.test.entity.Student;
import com.test.repo.StudentRepo;

@Service
public class StudentService {

    @Autowired
    private StudentRepo repo; // Injecting StudentRepo

    // Method to get all students
    public List<Student> getAllStudents() {
        return repo.findAll();
    }

    // Method to save a student
    public Student saveStudent(Student student) {
        return repo.save(student);
    }

    // Method to get a student by ID
    public Student getStudentById(int id) {
        return repo.findById(id).orElse(null);
    }

    // Method to delete a student by ID
    public void deleteStudent(int id) {
        repo.deleteById(id);
    }
}
