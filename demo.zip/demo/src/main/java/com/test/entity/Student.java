package com.test.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Column;
import jakarta.persistence.Table;

@Entity
@Table(name = "student_table") // Ensuring mapping with the correct table name
public class Student {

    @Id
    private int id;

    @Column(length = 100)
    private String name;

    @Column(length = 120)
    private String email;

    @Column(length = 30)
    private String branch;

    private int year;

    // Default Constructor
    public Student() {
        super();
    }

    // Parameterized Constructor
    public Student(int id, String name, String email, String branch, int year) {
        super();
        this.id = id;
        this.name = name;
        this.email = email;
        this.branch = branch;
        this.year = year;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    // toString() Method
    @Override
    public String toString() {
        return "Student [id=" + id + ", name=" + name + ", email=" + email + ", branch=" + branch + ", year=" + year + "]";
    }
}
